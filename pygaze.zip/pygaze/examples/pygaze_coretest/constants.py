# constants for PyGaze_supertest.py

DISPTYPE = 'psychopy'
DISPSIZE = 1920, 1080